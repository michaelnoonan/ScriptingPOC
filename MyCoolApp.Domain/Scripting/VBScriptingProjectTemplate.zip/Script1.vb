﻿Module Script1
    Sub Main()
        Dim name As String = InputBox("What is your name?")
        MsgBox("Hello " & name)
    End Sub
End Module
