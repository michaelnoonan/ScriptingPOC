﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("{{ProjectName}}")> 
<Assembly: AssemblyProduct("{{ProjectName}}")> 
<Assembly: AssemblyCopyright("Copyright ©  {{Year}}")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

<Assembly: AssemblyVersion("1.0.*")> 
